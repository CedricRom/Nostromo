package ui;

import javax.swing.JFrame;
import javax.swing.JButton;

public class Window {
	public static void main(String[] args){
		
		/** Window characteristics **/ 
		JFrame window = new JFrame();
		window.setTitle("Nostromo");
		window.setSize(1200,400);
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	
		/** Buttons **/
		JButton launch = new JButton();		
		window.add(launch);
		launch.setLocation(50, 50);
		launch.setSize(5,5);
		launch.setVisible(true);
		launch.setText("Launch");
		
		/*************Cedric part**************************/
	}
}
