package trajectory;

import java.util.ArrayList;

//import java.math.*;
public class Escape_Earth {
	
	
	double mass; //kg
	double poussee; //N
	//String lanceur; mettre en entrée les caractéristiques du lanceur masse, altitude au décollage en fonction 
	// de LEO, GTO ou escape 
	double Isp; //s Isp et poussée dépendent du moteur considéré
	
	
	
	final double mu_T= 3.986004418e14 ;
	final double alt_SOI_T = 925000000; //m
	final double RT=6371000; //m
	final double g0=9.81; // m.s^-2

	public Escape_Earth(double mass, double poussee, double isp) {
		this.mass = mass;
		this.poussee = poussee;
		this.Isp = isp;
	}
	
	// Renvoie ArrayList delta V, delta masse, temps (jours)
	public ArrayList<Double> LEO_to_Escape(double alt_LEO) { // l'altitude LEO en m à laquelle le lanceur peut amener sans 
												//compter le rayon de la TERRE
		double v0=Math.sqrt(mu_T/(alt_LEO+RT));
		double m0=this.mass;
		double v=v0;
		double vnew=v0;
		double dV=0.0;
		double dV_global=0;
		double m=m0;
		double a=alt_LEO+RT;
		double t=0.0;
		double deltaT=86400;
		int i=0;
		ArrayList<Double> list_param= new ArrayList<Double>();
		System.out.println(a);
		while (a<alt_SOI_T) {
			a=a/Math.pow((1-this.poussee*deltaT/(m*v)),2);
			vnew=Math.sqrt(mu_T/a);
			dV=vnew-v;
			dV_global=dV_global+dV;
			m=m+m*(1-Math.exp(-dV/(this.Isp*g0)));
			v=vnew;
			i=i+1;
			t=t+deltaT;
			System.out.println(a);
		}
		System.out.println("Terminé");
		System.out.println("Temps (jour): ");
		System.out.println(t/86400);
		System.out.println(i);
		System.out.println("Masse: ");
		System.out.println(m);
		list_param.add(dV_global);
		list_param.add(m0-m);
		list_param.add(t/86400);
		return list_param;
		
		

	}

	public double temps_LEO_to_Escape(double alt_LEO) {
		double f1=1/Math.sqrt(alt_LEO+RT)-1/Math.sqrt(alt_SOI_T);
		double f2=Math.sqrt(mu_T)/(this.poussee/this.mass);
		double T=f1*f2/86400;
		return T;
		
	}
	
	public ArrayList<Double> GTO_to_Escape(double alt_GTO_perigee, double alt_GTO_apogee) {
		// Raisonnement isoénérgétique
		// Aire de l'ellipse GTO
		double A_GTO=Math.PI*(alt_GTO_perigee+RT)*(alt_GTO_apogee+RT);
		// Rayon orbite circulaire équivalent
		double Req=Math.sqrt(A_GTO/Math.PI);
		ArrayList<Double> list_param= new ArrayList<Double>();

		double v0=Math.sqrt(mu_T/Req);
		double m0=this.mass;
		double v=v0;
		double vnew=v0;
		double dV=0.0;
		double dV_global=0;
		double m=m0;
		double a=Req;
		double t=0.0;
		double deltaT=86400;
		int i=0;
		System.out.println(a);
		while (a<alt_SOI_T) {
			a=a/Math.pow((1-this.poussee*deltaT/(m*v)),2);
			vnew=Math.sqrt(mu_T/a);
			dV=vnew-v;
			dV_global=dV_global+dV;
			m=m+m*(1-Math.exp(-dV/(this.Isp*g0)));
			v=vnew;
			i=i+1;
			t=t+deltaT;
			System.out.println(a);
		}
		System.out.println("Terminé");
		System.out.println("Temps (jour): ");
		System.out.println(t/86400);
		System.out.println(i);
		System.out.println("Masse: ");
		System.out.println(m);
		list_param.add(dV_global);
		list_param.add(m0-m);
		list_param.add(t/86400);
		return list_param;
		
	}
	
	public ArrayList<Double> Escape(double deltaV, double temps) {
		ArrayList<Double> list_param = new ArrayList<Double>();
		list_param.add(deltaV);
		list_param.add(0.0);
		list_param.add(temps/86400);
		return list_param;
		
	}
	

	
}

