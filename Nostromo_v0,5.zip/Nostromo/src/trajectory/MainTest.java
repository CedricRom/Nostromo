package trajectory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;



public class MainTest {

	public static void main(String[] args) throws ParseException {
		
		final double UA = 1.496e11; //m
		/**EscapeEarth traj=new EscapeEarth(15000, 4.5, 3000);
		double dV=traj.deltaV_LEO_to_Escape(1000000);
		double T=traj.temps_LEO_to_Escape(1000000);
		System.out.println(T);
		System.out.println(dV);
		
		EscapeEarth trajGTO=new EscapeEarth(10000, 4.5, 3000);
		double dV=trajGTO.deltaV_GTO_to_Escape(200000, 36000000);
		System.out.println(dV);*/
		

		Reach_Asteroid re=new Reach_Asteroid(3000);
		ArrayList<Double> list= re.rdv(new Date(), 4.5, 15000.0);
		System.out.println(list.toString());
	}

}
