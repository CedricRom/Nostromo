package trajectory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

public class Reach_Asteroid {	
	double aphelion; //m
	double semi_major_axis; //m
	double inclination; //rad
	double perihelion; //m
	double meanmotion; //deg per day
	double eccentricity;
	double mean_anomaly; //rad
	double ascending_node; //rad
	double arg_perihelion; //rad
	double emoid;
	double Isp;
	final double UA = 1.496e11; //m
	final double deg2rad = Math.PI/180 ;
	final double muS = 132712440018e9; //m^3/s^2
	
	final double sma_Earth=UA;
	final double inc_Earth=1.578690*deg2rad;
	final double ecc_Earth=	0.01671123;
	final double meanmotion_Earth=360/(365.25);
	final double MA_Earth=357.51716*deg2rad;
	final double AN_Earth=deg2rad*348.73936;
	final double argP_Earth=deg2rad*114.20783;
	final double rP_Earth=sma_Earth*(1-ecc_Earth);
	final double rA_Earth=sma_Earth*(1+ecc_Earth);
	
	public Reach_Asteroid(double Isp) throws ParseException {
		// NEA (PHA-O) 3414843_2008_EV5, epoch: 2458000.5
		this.Isp=Isp;
		this.aphelion = 1.0383*UA; 
		this.semi_major_axis = 0.9583*UA;
		this.inclination = 7.4368*deg2rad;
		this.perihelion = 0.8783*UA;
		this.meanmotion =1.047233762;
		this.eccentricity = 0.0835;
		this.mean_anomaly = 213.55*deg2rad;
		this.ascending_node = 93.390*deg2rad;
		this.arg_perihelion = 236.72*deg2rad;
		this.emoid=0.0149*UA;
		
		
	}
	
	
	
	public ArrayList<Double> rdv(Date date, double poussee, double masse) {
		long epoch2008=1228518000;
		long epochJ2000=946728000;
		long epochdate=date.getTime();
		
		double mean_anomaly=this.mean_anomaly+(this.meanmotion/86400)*(Math.PI/180)*(epochdate-epoch2008);
		double MA_T=this.MA_Earth+(this.meanmotion_Earth/86400)*(Math.PI/180)*(epochdate-epochJ2000);
		// true anomaly derivation
		double trueanomaly_T= MA_T+(2*this.eccentricity-0.25*Math.pow(this.eccentricity,3))*Math.sin(MA_T)+(5/4)*Math.sin(2*MA_T)*Math.pow(this.eccentricity, 2);
		trueanomaly_T= trueanomaly_T % (2*Math.PI);
		double deltaV_inc=(2*Math.sin(0.5*(this.inclination-this.inc_Earth))*Math.sqrt(1-Math.pow(this.eccentricity, 2))*Math.cos(this.arg_perihelion+trueanomaly_T)*this.semi_major_axis*this.meanmotion)/(1+this.eccentricity*Math.cos(trueanomaly_T));
		System.out.println(deltaV_inc);
		
		double rp1=this.sma_Earth*(1-this.ecc_Earth);
		double ra1=this.sma_Earth*(1+this.ecc_Earth);
		double rp2=this.semi_major_axis*(1-this.eccentricity);
		double ra2=this.semi_major_axis*(1+this.eccentricity);

		double dV_global = Math.sqrt(2*muS/rp1) - Math.sqrt(muS*(2/rp1-2/(ra1+rp1)))+Math.sqrt(2*muS/rp2)-Math.sqrt(muS*(2/rp2-2/(ra2+rp2)));
		
		double dv_possible=(poussee/masse)*86400; // en 1 jour
		long nb_iter=Math.round(dV_global/dv_possible);
		
		double rp_step = Math.abs(rp1-rp2)/nb_iter;
		double ra_step=Math.abs(ra1-ra2)/nb_iter;
		double rp0=rp1;
		double ra0=ra1;
		double rp=rp1;
		double ra=ra1;
		double e=this.ecc_Earth;
		double a=this.ecc_Earth;
		double r=0;
		double vold=0;
		double vnew=0;
		double mean_anomaly_curr=MA_T%(2*Math.PI);
		double E=Math.PI;
		double dV_a_e=0;
		//delta t de 86400 s
		for (int i=0;i<=nb_iter;i++) {
			E=Math.PI;
			for (int j=0;j<4;j++) {
				//True anoamly
				E=mean_anomaly_curr-e*(E*Math.cos(E)-Math.sin(E))/(1-e*Math.cos(E));
			}
			E=E%(2*Math.PI);
			r=a*(1-e*Math.cos(E));
			vold=Math.sqrt(muS*(2/r-1/a));
			
			rp=rp-rp_step;
			ra=ra+ra_step;
			e=(ra-rp)/(ra+rp);
			a=(ra+rp)/2;
			mean_anomaly_curr=(mean_anomaly_curr+86400*this.meanmotion_Earth)%(Math.PI*2);
			E=Math.PI;
			for (int j=0;j<4;j++) {
				//True anomaly
				E=mean_anomaly_curr-e*(E*Math.cos(E)-Math.sin(E))/(1-e*Math.cos(E));
			}
			E=E%(2*Math.PI);
			r=a*(1-e*Math.cos(E));
			vnew=Math.sqrt(muS*(2/r-1/a));
			System.out.println(a);
			dV_a_e=dV_a_e+Math.abs(vnew-vold);
			
		}
		
		//System.out.println(dV_a_e);
		double nb_itera=nb_iter;
		// ADA rajouter raan et wper
		// Ajuster l'argument du périgée
		double alpha=90*deg2rad;
		double delta_v_per= Math.sqrt(muS/a)*(e/Math.sqrt(1-e*e))*2*alpha*Math.abs(this.arg_perihelion-this.argP_Earth)/(3*alpha-Math.cos(alpha)*Math.sin(alpha));
		// Ajuster le RAAN
		double delta_v_raan=Math.PI*0.5*Math.sqrt(muS/a)*Math.sin(this.inclination)*Math.abs(this.ascending_node-this.AN_Earth);
		
		ArrayList<Double> list_param = new ArrayList<Double>();
		double dv_tot=delta_v_raan+delta_v_per+dV_a_e;
		list_param.add(dv_tot);
		double deltaM=masse*(1-Math.exp(-dv_tot/this.Isp*9.81));
		list_param.add(deltaM);
		list_param.add(nb_itera);
		return list_param;
	}
	

}
