package main;

import cargo.*;
import asteroid.*;


public class Mission {

	Asteroid cible;		// nom de l asteroide
	double distance;		// distance totale a parcourir (ou du parcours jusqu a l asteroide ?) (m)
	double duration;		// duree totale de la mission (ou du parcours jusqu a l asteroide ?) (s ?)
	double returning_mass; // masse a ramener de la mission (kg)  <- VARIABLE LA PLUS IMPORTANTE
	double total_mass;		// kg
	Propulsion propulsion; //voir classe de cargo
	double distance_soleil; // m
	double puissance; //
	double panel_mass; //masse des panneaux en kg
	//others

	Mission(Asteroid cible, double returning_mass, Propulsion propulsion) {
		this.cible = cible;
		this.returning_mass = returning_mass;
		this.propulsion = propulsion;

		//... depending on others parts, if something is needed
			
		// ...
	}

	/** Calculate characteristics needed for the launch **/
	private void prepare() {
		
		/******************************Tomas part*********************/
		
		/**********************Baptiste part**************************/
		double rendement = 0.25;
		double transfert = 0.8;
		double puissance_Terre = 1360.8;
		double distance_Terre = 149.6*Math.pow(10,9);	 //distance en m
		double masse_ARM = 1100;
		double surface_ARM = 90;
		
		double surface = this.puissance/(rendement*transfert*puissance_Terre*Math.pow(distance_Terre/this.distance_soleil,2));
		this.panel_mass = (surface/surface_ARM)*masse_ARM;

	}

	/** Calculate the distance, duration etc... of the mission **/
	public void launch() {
		this.prepare(); // ou directement dans le constructeur ?
		
		/**********************Dorian part******************************/
	}
	
	public double MissionCost() {
		double cost = 0;

		// Calcul du cout total de la mission
		/**********************Camille part*****************************/
		
		
		return cost;
	}
	
	public double KilometerCost() {
		double kmCost;
		kmCost = this.MissionCost() / this.distance ;		
		//Calcul du cout par kilometres de la mission.
		return kmCost;
	}
	
	
	
	public static void main(String[] args) {
		
		Asteroid target = new Asteroid(asteroid.AsteroidsList.Hayabusa_162173_Ryugu);
		Propulsion ionic = new Propulsion(PropulsionList.T6_qnetiq_bepi_colombo);
		Mission first_try = new Mission(target, 500, ionic);
		
		first_try.launch();
		first_try.cible.show_all();
		first_try.propulsion.show_all();
		System.out.println("Mission total cost: "+first_try.MissionCost()+"�.");
		System.out.println("Mission cost per kilometer: "+first_try.KilometerCost()+"�");
	}
	
}
