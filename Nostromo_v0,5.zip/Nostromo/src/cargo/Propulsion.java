package cargo;

import cargo.PropulsionList;

public class Propulsion {
	PropulsionList name; 
	String typeOf_fuel;
	//String type_moteur;   // GIE ou HALL
	double dry_mass; 	//Quantité em kg
	double ISP; 		// impulsion spécifique em s (nécessaire aux calculs) 
	double thrust; 		// poussée max en N (nécessaire aux calculs)
	double power;      // pouissance max en W (nécessaire aux calculs)
	//…

	public Propulsion(PropulsionList nom_propu)  {
		this.name = nom_propu;
		switch(nom_propu) {
		// Moteur type GIE 
		case NSTAR_boeing:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 48;
			this.ISP = 3100 ;
			this.thrust = 0.092;
			this.power = 2570 ;
		case XIPS25_l3_boeing:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 13.7;
			this.ISP = 3550 ;
			this.thrust = 0.092;
			this.power = 2570 ;
		case T6_qnetiq_bepi_colombo:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5;
			this.ISP = 4000 ;
			this.thrust = 0.125;
			this.power = 4500;
		case T7_qnetiq:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier 
			this.ISP = 4000 ;
			this.thrust = 0.290;
			this.power = 7000;
		case NEXTC_aerojet_rocketdyne:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 4190 ;
			this.thrust = 0.236;
			this.power = 6300;
		case RIT2X_ariane:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 2800 ;
			this.thrust = 0.205;
			this.power = 5000;
		// Moteur à effet HALL
		case PPS1350_safran:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 31; 
			this.ISP = 1700 ;
			this.thrust = 0.088;
			this.power = 1500;
		case PPS5000_safran:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 1950 ;
			this.thrust = 0.250;
			this.power = 5000;
		case PPS20000_safran:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 2500 ;
			this.thrust = 0.980;
			this.power = 20000;
		case XR5_aerojet_rocketdyne:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 1850 ;
			this.thrust = 0.280;
			this.power = 4500;
		case AEPS_aerojet_rocketdyne:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 100; // A verifier
			this.ISP = 2800 ;
			this.thrust = 0.589;
			this.power = 13300;
		case SPT230_fakel_russe:
			this.typeOf_fuel = "Xe";
			this.dry_mass = 8.5; // A verifier
			this.ISP = 2700 ;
			this.thrust = 0.784;
			this.power = 1500;
		}
		
	}
	
	public void show_all() {
		System.out.println("Propulsion characteristics: ");
		System.out.println("	-name: "+this.name.toString());
		System.out.println("	-type: "+this.typeOf_fuel);
		System.out.println("	-dry mass: "+this.dry_mass+" kg");
		System.out.println("	-ISP: "+this.ISP+" s");
		System.out.println("	-thrust: "+this.thrust+" N");
		System.out.println("	-power: "+this.power+" W\n");
	}
}

