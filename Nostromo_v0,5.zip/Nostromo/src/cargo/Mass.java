package cargo;

public class Mass {
	public static double FinalCalculation(double max_weight,
										  double deltV,
										  double solarPanel_weight) {
	
		return 0;
	}
}
