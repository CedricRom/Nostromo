package cargo;

public enum OrbitsList {
	LEO,
	GTO,
	Escape;
}
