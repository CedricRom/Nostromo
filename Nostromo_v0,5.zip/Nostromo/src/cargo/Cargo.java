package cargo;

public class Cargo {
	double diameter; //m
	double length; //m
	double total_weight; //kg
	double transportable_weight; //kg
	Propulsion propulsion;
	
	/** 
	 * @param diameter
	 * @param length
	 * @param total_weight
	 * @param transportable_weight
	 * @param propulsion
	 */
	
	/**** Constructors ****/
	public Cargo(double diameter, double length, double total_weight, double transportable_weight, Propulsion propulsion) {
		this.diameter = diameter;
		this.length = length;
		this.total_weight = total_weight;
		this.transportable_weight = transportable_weight;
		this.propulsion = propulsion;
	}
	
	
	/**** "get" functions ****/
	public double getDiameter() {
		return this.diameter;
	}
	public double getLength() {
		return this.length;
	}
	public double getTotalWeight() {
		return this.total_weight;
	}
	public double getTransportableWeight() {
		return this.transportable_weight;
	}
	public Propulsion getPropulsion() {
		return this.propulsion;
	}
}
