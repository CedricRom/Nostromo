package cargo;

public class Launcher {
	LauncherList typeOf;
	OrbitsList orbit;
	private double max_weight; //kg
	private double cargo_max_length; //m
	private double cargo_max_diameter; //m
	
	/**
	 * @param typeOf
	 * @param orbit
	 * @param max_weight
	 * @param cargo_max_length
	 * @param cargo_max_diameter  
	 */
	
	/**** Constructors ****/
	public Launcher(LauncherList typeOf, OrbitsList orbit){
		switch(orbit) {
		case LEO:
			this.orbit = OrbitsList.LEO;
			break;
		case GTO:
			this.orbit = OrbitsList.GTO;
			break;
		case Escape:
			this.orbit = OrbitsList.Escape;
			break;
		default:
			this.orbit = OrbitsList.GTO;
			System.out.println("Unknown orbit. Possibilities are \"LEO\",\"GTO\" and \"Escape\".\n GTO charged by default.");
		}
		
		switch(typeOf) {
		case Ariane_64:
			this.typeOf = LauncherList.Ariane_64;
			this.cargo_max_diameter = 5.4;
			this.cargo_max_length = 20;
			if(OrbitsList.GTO.equals(orbit)) this.max_weight = 11500;
			else if(OrbitsList.LEO.equals(orbit)) this.max_weight = 21650;
			else this.max_weight = 6400;
			break;
		case Falcon_Heavy:
			this.typeOf = LauncherList.Falcon_Heavy;
			this.cargo_max_diameter = 5.2;
			this.cargo_max_length = 13.1;
			if(OrbitsList.GTO.equals(orbit)) this.max_weight = 26700;
			else if(OrbitsList.LEO.equals(orbit)) this.max_weight = 63800;
			else this.max_weight = 16800;  // charge utile pour une mission vers Mars selon Wikipedia
			break;
		default:
			System.out.println("Unknown launcher. Launching \"Falcon Heavy\" as default.");
			this.typeOf = LauncherList.Falcon_Heavy;
			this.cargo_max_diameter = 5.2;
			this.cargo_max_length = 13.1;
			if(OrbitsList.GTO.equals(orbit)) this.max_weight = 26700;
			else if(OrbitsList.LEO.equals(orbit)) this.max_weight = 63800;
			else this.max_weight = 16800;
		}
	}
	
	
	/**** "get" functions ****/
	public double getMaxWeight() {
		return this.max_weight;
	}
	public double getCargoMaxLenght() {
		return this.cargo_max_length;
	}
	public double getCargoMaxDiameter() {
		return this.cargo_max_diameter;
	}
	
	
}
