package cargo;

public enum LauncherList {
	Ariane_64,
	Falcon_Heavy,
	
	;
}
