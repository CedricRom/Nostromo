package cargo;

public enum PropulsionList {
	// Moteur type GIE
	NSTAR_boeing,
	XIPS25_l3_boeing,
	T6_qnetiq_bepi_colombo,
	T7_qnetiq,
	NEXTC_aerojet_rocketdyne,
	RIT2X_ariane,
	// Moteur type a� effet Hall
	PPS1350_safran,
	PPS5000_safran,
	PPS20000_safran,
	XR5_aerojet_rocketdyne,
	AEPS_aerojet_rocketdyne,
	SPT230_fakel_russe
}