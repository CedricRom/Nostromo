package asteroid;

public enum AsteroidsList {
	ARM_3414843_2008_EV5,
	Hayabusa_162173_Ryugu,
	OSIRISREX_101955_Bennu,
	
	;
}
