package asteroid;

public class OrbitAsteroid {
	AsteroidsList asteroid;
	double aphelion; //km
	double semi_major_axis; //km
	double inclination; //rad
	double perihelion; //km
	double period; //day
	double eccentricity;
	double mean_anomaly; //rad
	double ascending_node; //rad
	double arg_perihelion; //rad
	double emoid;
	final double UA = 1.496e8; //km
	final double deg2rad = Math.PI/180 ;
	
	public OrbitAsteroid(AsteroidsList asteroid) {
		
		this.asteroid = asteroid;
		switch(asteroid) {
		case ARM_3414843_2008_EV5:
			break;
		case Hayabusa_162173_Ryugu: 
			this.aphelion = 1.4159*UA; 
			this.semi_major_axis = 1.1896*UA;
			this.inclination = 5.8837*deg2rad;
			this.perihelion = 0.96331*UA;
			this.period = 473.9148;
			this.eccentricity = 0.19022575;
			this.mean_anomaly = 3.983244*deg2rad;
			this.ascending_node = 251.6197*deg2rad;
			this.arg_perihelion = 211.4258*deg2rad;
			//this.emoid = emoid;
			break;
		case OSIRISREX_101955_Bennu:
			break;
		default:
			System.out.println("Unknown asteroid. Ryugu set by default.");
			this.aphelion = 1.4159*UA; 
			this.semi_major_axis = 1.1896*UA;
			this.inclination = 5.8837*deg2rad;
			this.perihelion = 0.96331*UA;
			this.period = 473.9148;
			this.eccentricity = 0.19022575;
			this.mean_anomaly = 3.983244*deg2rad;
			this.ascending_node = 251.6197*deg2rad;
			this.arg_perihelion = 211.4258*deg2rad;
			//this.emoid = emoid;
		}
	}


	public AsteroidsList getAsteroid() {
		return asteroid;
	}
	public void setAsteroid(AsteroidsList asteroid) {
		this.asteroid = asteroid;
	}
	public double getAphelion() {
		return aphelion;
	}
	public void setAphelion(double aphelion) {
		this.aphelion = aphelion;
	}
	public double getSemi_major_axis() {
		return semi_major_axis;
	}
	public void setSemi_major_axis(double semi_major_axis) {
		this.semi_major_axis = semi_major_axis;
	}
	public double getInclination() {
		return inclination;
	}
	public void setInclination(double inclination) {
		this.inclination = inclination;
	}
	public double getPerihelion() {
		return perihelion;
	}
	public void setPerihelion(double perihelion) {
		this.perihelion = perihelion;
	}
	public double getPeriod() {
		return period;
	}
	public void setPeriod(double period) {
		this.period = period;
	}
	public double getEccentricity() {
		return eccentricity;
	}
	public void setEccentricity(double eccentricity) {
		this.eccentricity = eccentricity;
	}
	public double getMean_anomaly() {
		return mean_anomaly;
	}
	public void setMean_anomaly(double mean_anomaly) {
		this.mean_anomaly = mean_anomaly;
	}
	public double getAscending_node() {
		return ascending_node;
	}
	public void setAscending_node(double ascending_node) {
		this.ascending_node = ascending_node;
	}
	public double getArg_perihelion() {
		return arg_perihelion;
	}
	public void setArg_perihelion(double arg_perihelion) {
		this.arg_perihelion = arg_perihelion;
	}
	public double getEmoid() {
		return emoid;
	}
	public void setEmoid(double emoid) {
		this.emoid = emoid;
	} 
}
